# super-hero-hunter
 This super-hero hunter application build to search for any superhero ,get details about any superhero and to add these superheroes to favourite list.
## process to execute 
Here superheroApi("https://www.superheroapi.com/") is used to fetch the data.
code get executed from index.html page which is the Home page of this application.From Here we go favourites list from favourites button and get the deatils about the 
superhero by clicking on the search-results.
